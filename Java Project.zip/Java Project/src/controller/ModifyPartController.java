package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Part;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/** This class displays Modify Part screen where the user can modify the data of an item.*/
public class ModifyPartController implements Initializable {

    /** UI Control Label for Modify Part.*/
    @FXML
    public Label changeLabel;

    /** UI Control RadioButton for In-House.*/
    @FXML
    public RadioButton inHouse;

    /** UI Control RadioButton for Outsourced.*/
    @FXML
    public RadioButton outsourced;

    /** UI Control TextField for Part ID.*/
    @FXML
    public TextField modifyPartIdTxt;

    /** UI Control TextField for Part Name.*/
    @FXML
    private TextField modifyPartNameTxt;

    /** UI Control TextField for Part Inventory.*/
    @FXML
    private TextField modifyPartInvTxt;

    /** UI Control TextField for Part Price.*/
    @FXML
    private TextField modifyPriceCostTxt;

    /** UI Control TextField for Part Max.*/
    @FXML
    private TextField modifyMaxTxt;

    /** UI Control TextField for Part Min.*/
    @FXML
    public TextField modifyMinTxt;

    /** UI Control TextField for Part Machine ID.*/
    @FXML
    private TextField modifyMachineIDTxt;

    /** Defines a variable of type int that will be passed to sendPartData*/
    private int index;

    /**This is the initialize method. This is the first method that is called when the screen associated with this controller gets instantiated.*/
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    /**
     * This is the EventHandler for the Cancel button.
     * Sends the user back to the main screen.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void toMainForm(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        Stage stage = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 965, 500);
        stage.setScene(scene);
        stage.show();
    }

    /**
     *This method transfers data from the Main screen to Modify Part screen.
     * Sets data into the fields that the user can modify.
     * @param index The index of the array list.
     * @param part Part object.
     */
    public void sendPartData(int index, Part part){

        try
        {
            /** Sets the values of the TextFields*/

            this.index = index; /** Assigns the index passed to the global variable.*/
            modifyPartIdTxt.setText(String.valueOf(part.getId()));
            modifyPartNameTxt.setText(part.getName());
            modifyPartInvTxt.setText(String.valueOf(part.getStock()));
            modifyPriceCostTxt.setText(String.valueOf(part.getPrice()));
            modifyMaxTxt.setText(String.valueOf(part.getMax()));
            modifyMinTxt.setText(String.valueOf(part.getMin()));


            /** Verifies if the part passed is an instance of the In-House class.*/

            if(part instanceof InHouse)
            {
                modifyMachineIDTxt.setText(String.valueOf(((InHouse) part).getMachineId())); /** Part is cast to an In-House type in order to access the getMachineId method.*/
                inHouse.setSelected(true); /** Sets the InHouse radio button.*/
                changeLabel.setText("Machine ID"); /** Label is set to display "Machine ID".*/
            }
            /** Verifies if the part is an instance of the Outsource class.*/

            else if(part instanceof Outsourced)
            {
                modifyMachineIDTxt.setText(((Outsourced) part).getCompanyName()); /** Part is cast to an Outsource type in order to get access to the get.CompanyName method. */
                outsourced.setSelected(true); /** Sets the Outsource radio button.*/
                changeLabel.setText("Company Name"); /** Label is set to display "Company Name".*/
            }
        }
        catch(NumberFormatException e)
        {
            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error Dialog");
            selectItemError.setContentText("Please enter numbers in the min, max, machineid and price fields.");
            selectItemError.showAndWait();
        }
    }

    /**
     * This is the EventHandler for the Save button.
     * The user can save the newly modified part to inventory.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionSave(ActionEvent actionEvent) throws IOException {

        try
            {
                String name = modifyPartNameTxt.getText(); /**Getting input from the partNameTxt field and assigning it to string variable name**/
                int stock = Integer.parseInt(modifyPartInvTxt.getText()); /**Getting input from the partInvTxt and converting it to an integer**/
                double price = Double.parseDouble(modifyPriceCostTxt.getText()); /**Getting input from the partPriceCostTxt and converting it to a double**/
                int max = Integer.parseInt(modifyMaxTxt.getText()); /**Getting input from the partMaxTxt and converting it to an integer**/
                int min = Integer.parseInt(modifyMinTxt.getText()); /**Getting input from the partMinTxt and converting it to an integer**/
                int id = Integer.parseInt(modifyPartIdTxt.getText());

                /** Verifies if the In-House radio button is selected and the inventory level is between max and min.*/

                if (inHouse.isSelected() && stock < max && stock > min || stock == max || stock == min)  {

                    int machineId = Integer.parseInt(modifyMachineIDTxt.getText()); /**Getting input from the partMachineTxt and converting it to an integer**/
                    InHouse inHousePart = new InHouse(id, name, price, stock, min, max, machineId); /** Creates In-House part object and assigns the values from the TextFields.*/
                    Inventory.updatePart(index, inHousePart); /** Calls the updatePart*/

                    /**Returns the user to the main form**/
                    Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root, 965, 500);
                    stage.setScene(scene);
                    stage.show();
                }
                /**Verifies that stock is not greater than Max.*/
                else if (max < stock) {

                    Alert invError = new Alert(Alert.AlertType.ERROR);
                    invError.setTitle("Inventory Error");
                    invError.setContentText("Inventory should be between Max and Min.");
                    invError.showAndWait();
                }
                /** Verifies that Min is not greater than stock*/
                else if (max < min) {

                    Alert invError = new Alert(Alert.AlertType.ERROR);
                    invError.setTitle("Inventory Error");
                    invError.setContentText("Min should be less than Max.");
                    invError.showAndWait();
                }
                /** Verifies that stock is not less than Min.*/
                else if (min > stock) {

                    Alert invError = new Alert(Alert.AlertType.ERROR);
                    invError.setTitle("Inventory Error");
                    invError.setContentText("Inventory between Max and Min.");
                    invError.showAndWait();
                }

                /**Checks if Outsourced Radio Button is selected and if stock level is between Max and Min levels*/
                else if (outsourced.isSelected() && stock < max && stock > min) {

                    String companyName = modifyMachineIDTxt.getText();
                    Outsourced outsourcedPart = new Outsourced(id, name, price, stock, min, max, companyName);
                    Inventory.updatePart(index, outsourcedPart);

                    /**Returns the user to the main form**/
                    Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root, 965, 500);
                    stage.setScene(scene);
                    stage.show();
                }
            }
            catch (NumberFormatException e) /** Catches exemptions in case user enters wrong data type in the fields.*/
            {
                /** Displays error message in case the user inputs invalid values into the fields. */

                Alert emptyField = new Alert(Alert.AlertType.ERROR);
                emptyField.setTitle("Error Dialog");
                emptyField.setContentText("""
                            Please make sure you enter correct values in the fields.\s
                            - Inv should be a whole number.\s
                            - Price should contain decimals.\s
                            - Max should be a whole number.\s
                            - Min should be a whole number.\s
                            - Machine ID should be a whole number.\s
                            """);
                emptyField.showAndWait();
            }
    }

    /**
     * This is the EventHandler for the In-House radio button.
     * When the user selects the In-House radio button it displays the label "Machine ID".
     * @param actionEvent Not used.
     */
    public void onInHouse(ActionEvent actionEvent) {
        changeLabel.setText("Machine ID");
    }

    /**
     * This is the EventHandler for the Outsource radio button.
     * When the user selects the Outsource radio button it displays the label "Company Name".
     * @param actionEvent Not used.
     */
    public void onOutsourced(ActionEvent actionEvent) {
        changeLabel.setText("Company Name");
    }
}
