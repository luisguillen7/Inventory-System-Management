package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class displays the Modify Product screen where the user can modify the data of an item.*/
public class ModifyProductController implements Initializable {

    /** UI Control TextField for the Product ID.*/
    @FXML
    public TextField modifyProductIdTxt;

    /** UI Control TextField for the Product Name.*/
    @FXML
    public TextField modifyProductNameTxt;

    /** UI Control TextField for the Product Inventory.*/
    @FXML
    public TextField modifyProductInvTxt;

    /** UI Control TextField for the Product Max.*/
    @FXML
    public TextField modifyProductMaxTxt;

    /** UI Control TextField for the Product Min.*/
    @FXML
    public TextField modifyProductMinTxt;

    /** UI Control TextField for the Product Price.*/
    @FXML
    public TextField modifyProductPriceTxt;

    /** UI Control TextField for the Part Search bar.*/
    @FXML
    public TextField searchPartTxt;

    /** UI Control TableView for Part objects.*/
    @FXML
    public TableView<Part> modifyPartTableView;

    /** TableColumn for the Part ID.*/
    @FXML
    public TableColumn<Part, Integer> modifyPartIdCol;

    /** TableColumn for the Part Name.*/
    @FXML
    public TableColumn<Part, String> modifyNameCol;

    /** TableColumn for the Part Inv.*/
    @FXML
    public TableColumn<Part, Integer> modifyInvCol;

    /** TableColumn for the Part Price.*/
    @FXML
    public TableColumn<Part, Double> modifyPriceCostCol;

    /** UI Control TableView for the Associated Parts.*/
    @FXML
    public TableView<Part> modifyAssociatedTableView;

    /** TableColumn for the Associated Part ID.*/
    @FXML
    public TableColumn<Part, Integer> modifyAssociatedIdCol;

    /** TableColumn for the Associated Part Name.*/
    @FXML
    public TableColumn<Part,String> modifyAssociatedNameCol;

    /** TableColumn for the Associated Part Inv.*/
    @FXML
    public TableColumn<Part, Integer> modifyAssociatedInvCol;

    /** TableColumn for thew Associated Part Price.*/
    @FXML
    public TableColumn<Part, Double> modifyAssociatedPriceCostCol;

    /**Creates a reference variable called tempList that references the Part ObservableList*/
    private ObservableList<Part> tempList = FXCollections.observableArrayList();

    /**Creates a global product object and is initialized with default values.*/
    Product product = new Product(0, null, 0.0, 0, 0, 0);

    /** Defines a variable of type int that will be passed to sendPartData*/
    private int index;

    /**This is the initialize method. This is the first method that is called when the screen associated with this controller gets instantiated.*/
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /**PART TABLEVIEW*/

        /**This statement sets items inside the Part Table*/
        modifyPartTableView.setItems(Inventory.getAllParts());

        /**This statement gets the id from the getId method of every Part object created.*/
        modifyPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        /**This statement gets the name from the getName method of every Part object created.*/
        modifyNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        /**This statement gets the inventory from the getStock method of every Part object created.*/
        modifyInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        /**This statement gets the price from the getPrice method of every Part object created.*/
        modifyPriceCostCol.setCellValueFactory(new PropertyValueFactory<>("price"));


        /**PART TABLEVIEW*/

        /**This statement sets items inside the Part Table*/
        modifyAssociatedTableView.setItems(tempList);

        /**This statement gets the id from the getId method of every Part object created.*/
        modifyAssociatedIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        /**This statement gets the name from the getName method of every Part object created.*/
        modifyAssociatedNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        /**This statement gets the inventory from the getStock method of every Part object created.*/
        modifyAssociatedInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        /**This statement gets the price from the getPrice method of every Part object created.*/
        modifyAssociatedPriceCostCol.setCellValueFactory(new PropertyValueFactory<>("price"));


    }

    /**
     * This is the EventHandler for the Search bar.
     * It filters and sets items on the TableView when the item is searched by name and highlights the item when the item is searched by ID.
     * @param actionEvent Not used.
     */
    public void onActionSearch(ActionEvent actionEvent) {

        try
        {
            String partIdSearched = searchPartTxt.getText();
            int id = Integer.parseInt(partIdSearched);
            Part t = Inventory.lookupPart(id);
            modifyPartTableView.getSelectionModel().select(t);

        }catch(Exception e)
        {
            String partSearched = searchPartTxt.getText();
            ObservableList<Part> partsNamed = Inventory.lookupPart(partSearched);
            modifyPartTableView.setItems(partsNamed);

        }

        if(!(Inventory.partFound)){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning Dialog");
            alert.setContentText("Part Not Found");
            alert.showAndWait();
            searchPartTxt.setText("");
        }

    }

    /**
     *This method transfers data from the Main screen to Modify Product screen.
     * Sets data into the fields that the user can modify.
     * @param index The index of the array list.
     * @param product Product object.
     */
    public void sendProductData(int index, Product product){

        try
        {
            /** TextFields from the ModifyProductController are set values from the product getters.*/
            this.index = index;
            this.product = product;
            modifyProductIdTxt.setText(String.valueOf(product.getId()));
            modifyProductNameTxt.setText(product.getName());
            modifyProductInvTxt.setText(String.valueOf(product.getStock()));
            modifyProductPriceTxt.setText(String.valueOf(product.getPrice()));
            modifyProductMaxTxt.setText(String.valueOf(product.getMax()));
            modifyProductMinTxt.setText(String.valueOf(product.getMin()));

            /** Associated Parts TableView values are set from getting the list from the product class.*/
            modifyAssociatedTableView.setItems(product.getAllAssociatedParts());

            /** Creates copy of the list*/
            tempList.addAll(product.getAllAssociatedParts());

        }
        catch(NumberFormatException e)
        {
            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error Dialog");
            selectItemError.setContentText("Please enter numbers in the min, max and price fields.");
            selectItemError.showAndWait();
        }

    }

    /**
     * This is the EventHandler for the Add button.
     * A part is added to the associated parts TableView.
     * @param actionEvent Not used.
     */
    public void onAddAction(ActionEvent actionEvent) {

        if(modifyPartTableView.getSelectionModel().getSelectedItem() != null){
            Part partObject = modifyPartTableView.getSelectionModel().getSelectedItem();
            product.addAssociatedPart(partObject);

        }
        else{
            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error");
            selectItemError.setContentText("Please select an item to add.");
            selectItemError.showAndWait();
        }
    }

    /**
     * This is the EventHandler for the Remove Associated Part button.
     * An item from the associated parts TableView is removed.
     * @param actionEvent Not used.
     */
    public void onRemovePartAction(ActionEvent actionEvent) {

        /** Creates part instance that stores the item selected from the Associated TableView.*/

        Part selectedAssociatedPart = modifyAssociatedTableView.getSelectionModel().getSelectedItem();

        /** Verifies that am item is selected.*/
        if (selectedAssociatedPart != null) {

            /** Double-check if the item should be removed.*/

            Alert onExit = new Alert(Alert.AlertType.CONFIRMATION);
            onExit.setTitle("Item Deletion");
            onExit.setContentText("Are you sure you want to remove this item?");
            Optional<ButtonType> result = onExit.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {

                /** Remove the selected associated part */

                product.deleteAssociatedPart(selectedAssociatedPart);

            }
            else{

                /** Display error message if user clicks cancel in the confirmation dialogue box.*/

                Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                confirmedDeletion.setTitle("Parts");
                confirmedDeletion.setContentText("Part was not removed.");
                confirmedDeletion.show();

            }
        }
        else
        {
                /** Else statement executes an error message if no item is selected to delete.*/

                Alert selectItemError = new Alert(Alert.AlertType.ERROR);
                selectItemError.setTitle("Error");
                selectItemError.setContentText("Please select an item to delete.");
                selectItemError.showAndWait();
        }
    }


    /**
     * This is the EventHandler for the Save button.
     * Adds a new item to inventory, displays the item in the Products TableView and redirects the user to the main screen.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionSaveProduct(ActionEvent actionEvent) throws IOException {
        try {
            String name = modifyProductNameTxt.getText(); /**Getting input from the partNameTxt field and assigning it to string variable name**/
            int stock = Integer.parseInt(modifyProductInvTxt.getText()); /**Getting input from the partInvTxt and converting it to an integer**/
            double price = Double.parseDouble(modifyProductPriceTxt.getText()); /**Getting input from the partPriceCostTxt and converting it to a double**/
            int max = Integer.parseInt(modifyProductMaxTxt.getText()); /**Getting input from the partMaxTxt and converting it to an integer**/
            int min = Integer.parseInt(modifyProductMinTxt.getText()); /**Getting input from the partMinTxt and converting it to an integer**/
            int id = Integer.parseInt(modifyProductIdTxt.getText());

            if(stock < max && stock > min || stock == max || stock == min){

                product.setId(id); /**Not incremented*/
                product.setName(name);
                product.setStock(stock);
                product.setPrice(price);
                product.setMax(max);
                product.setMin(min);

                Inventory.updateProduct(index, product);

                /**The addPart method of the Inventory Class accepts an InHouse object and adds it to the list*/
                Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
                Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                Scene scene = new Scene(root, 965, 500);
                stage.setScene(scene);
                stage.show();
            }
            else if(max < stock)
            {
                Alert invError = new Alert(Alert.AlertType.ERROR);
                invError.setTitle("Inventory Error");
                invError.setContentText("Inventory should be between Max and Min.");
                invError.showAndWait();
            }
            else if(max < min)
            {
                Alert invError = new Alert(Alert.AlertType.ERROR);
                invError.setTitle("Inventory Error");
                invError.setContentText("Min should be less than Max.");
                invError.showAndWait();
            }
            else if(stock < min)
            {
                Alert invError = new Alert(Alert.AlertType.ERROR);
                invError.setTitle("Inventory Error");
                invError.setContentText("Inventory should be between Max and Min.");
                invError.showAndWait();
            }

        }
        catch(Exception e) /** Catches exemptions in case user enters wrong data type in the fields.*/
            {
                /** Displays error message in case the user inputs invalid values into the fields. */
                Alert emptyField = new Alert(Alert.AlertType.ERROR);
                emptyField.setTitle("Error Dialog");
                emptyField.setContentText("""
                                Please make sure you enter correct values in the fields.\s
                                - Inv should be a whole number.\s
                                - Price should contain decimals.\s
                                - Max should be a whole number.\s
                                - Min should be a whole number.\s
                                - Machine ID should be a whole number.\s
                                """);
                emptyField.showAndWait();
            }
    }

    /**
     * This is the EventHandler for the Cancel button.
     * Cancels the addition of a new product and redirects the user to the main screen.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void toMainForm(ActionEvent actionEvent) throws IOException {

        /**Clears Associated Parts TableView.*/

        product.getAllAssociatedParts().clear();
        product.getAllAssociatedParts().addAll(tempList);


        /** Loads Main Screen.*/

        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        Stage stage = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 965, 500);
        stage.setScene(scene);
        stage.show();

    }
}
