package controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class displays the Add Product screen where the user can add a new product to inventory.*/
public class AddProductController implements Initializable {

    /**UI Control TextField for Search bar.*/
    @FXML
    public TextField partProductSearchTxt;

    /**UI Control TextField for ID.*/
    @FXML
    public TextField productIDTxt;

    /**UI Control TextField for Name.*/
    @FXML
    public TextField productNameTxt;

    /**UI Control TextField for Inventory.*/
    @FXML
    public TextField productInvTxt;

    /**UI Control TextField for Price.*/
    @FXML
    public TextField productPriceTxt;

    /**UI Control TextField for Max.*/
    @FXML
    public TextField productMaxTxt;

    /**UI Control TextField for Min.*/
    @FXML
    public TextField productMinTxt;

    /**UI Control TableView to store Part objects.*/
    @FXML
    public TableView<Part> partProductTableView;

    /**TableColumn for ID.*/
    @FXML
    public TableColumn<Part, Integer> partProductIdCol;

    /**TableColumn for Name.*/
    @FXML
    public TableColumn<Part, String> partProductNameCol;

    /**TableColumn for Inventory.*/
    @FXML
    public TableColumn<Part, Integer> partProductInvCol;

    /**TableColumn for Price.*/
    @FXML
    public TableColumn<Part, Double> partProductPriceCol;

    /**UI Control TableView to store Part objects.*/
    @FXML
    public TableView<Part> associatedTableView;

    /**TableColumn for ID.*/
    @FXML
    public TableColumn<Part, Integer> associatedIdCol;

    /**TableColumn for Name.*/
    @FXML
    public TableColumn<Part, String> associatedNameCol;

    /**TableColumn for Inventory.*/
    @FXML
    public TableColumn<Part, Integer> associatedInvCol;

    /**TableColumn for Price.*/
    @FXML
    public TableColumn<Part, Double> associatedPriceCostCol;

     /**Creates a global product object and is initialized with default values.*/
     Product product = new Product(0, null, 0.0, 0, 0, 0);

    /**This is the initialize method. This is the first method that is called when the screen associated with this controller gets instantiated.*/
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /**PART TABLEVIEW*/

        /**This statement sets items inside the Part Table*/
        partProductTableView.setItems(Inventory.getAllParts());

        /**This statement gets the id from the getId method of every Part object created.*/
        partProductIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        /**This statement gets the name from the getName method of every Part object created.*/
        partProductNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        /**This statement gets the inventory from the getStock method of every Part object created.*/
        partProductInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        /**This statement gets the price from the getPrice method of every Part object created.*/
        partProductPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));


        /**ASSOCIATED PARTS TABLEVIEW*/

        /**This statement sets items inside the Part Table*/
        associatedTableView.setItems(product.getAllAssociatedParts());

        /**This statement gets the id from the getId method of every Part object created.*/
        associatedIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        /**This statement gets the name from the getName method of every Part object created.*/
        associatedNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        /**This statement gets the inventory from the getStock method of every Part object created.*/
        associatedInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        /**This statement gets the price from the getPrice method of every Part object created.*/
        associatedPriceCostCol.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    /**
     * This is the EventHandler for the Add button.
     * A part is added to the associated parts TableView.
     * @param actionEvent Not used.
     */
    public void onAddAssociatedPart(ActionEvent actionEvent) {

        /**Checks if an item in the partProductTableview is selected*/
        if(partProductTableView.getSelectionModel().getSelectedItem() != null){

            /**Creates a part object and gets assigned the item that is selected from the TableView*/
            Part partObject = partProductTableView.getSelectionModel().getSelectedItem();

            /**partObject is then added to the tempList*/
            product.addAssociatedPart(partObject);
        }
        else{
            /**Alert message is displayed if the user clicks the Add button without selecting an item first*/
            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error");
            selectItemError.setContentText("Please select an item to add.");
            selectItemError.showAndWait();
        }
    }

    /**
     * This is the EventHandler for the Remove Associated Part button.
     * An item from the associated parts TableView is removed.
     * @param actionEvent Not used.
     */
    public void onDeleteAssociatedPart(ActionEvent actionEvent) {

        /** Creates part instance that stores the item selected from the Associated TableView.*/

        Part selectedAssociatedPart = associatedTableView.getSelectionModel().getSelectedItem();

        /** Verifies that am item is selected.*/

        if(selectedAssociatedPart != null) {

            /** Confirm if the item should be removed.*/

            Alert onExit = new Alert(Alert.AlertType.CONFIRMATION);
            onExit.setTitle("Item Deletion");
            onExit.setContentText("Are you sure you want to remove this item?");
            Optional<ButtonType> result = onExit.showAndWait();

            if(result.isPresent() && result.get() == ButtonType.OK)
            {
                product.deleteAssociatedPart(selectedAssociatedPart);

                /** Displays dialog message when associated part is removed.*/

                Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                confirmedDeletion.setTitle("Associated Part Removal");
                confirmedDeletion.setContentText("Associated part was successfully removed.");
                confirmedDeletion.show();

            }
            else{

                /** Display error message if user clicks cancel in the confirmation dialogue box.*/

                Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                confirmedDeletion.setTitle("Parts");
                confirmedDeletion.setContentText("Part was not removed.");
                confirmedDeletion.show();

            }

        }
        else{
            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error");
            selectItemError.setContentText("Please select an item to delete.");
            selectItemError.showAndWait();
        }
    }

    /**
     * This is the EventHandler for when the user searches for an item.
     * The item can be searched and filtered by name and the item can be searched and highlighted by ID.
     * @param actionEvent Not used.
     */
    public void onActionSearch(ActionEvent actionEvent) {

        try
        {
            String partIdSearched = partProductSearchTxt.getText(); /**Get the text from the Search Bar.*/
            int id = Integer.parseInt(partIdSearched); /**Convert the text to an Integer.*/
            Part t = Inventory.lookupPart(id); /**Calls the lookUp method and assigns its value to a Part object.*/
            partProductTableView.getSelectionModel().select(t); /** Selects and highlights the item searched in the table.*/

        }catch(Exception e) /**Exception is executed in case the user searches item by name.*/
        {
            String partSearched = partProductSearchTxt.getText(); /**Get the text from the Search Bar.*/
            ObservableList<Part> partsNamed = Inventory.lookupPart(partSearched); /**Call the lookUp method and pass the string previously created.*/
            partProductTableView.setItems(partsNamed); /** Sets and displays items searched for in the table.*/
        }

        if(!(Inventory.partFound)){ /** This executes an error message in case the part is not found. */

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning Dialog");
            alert.setContentText("Part Not Found");
            alert.showAndWait();
            partProductSearchTxt.setText("");
        }
    }

    /**
     * This is the EventHandler for the Cancel button.
     * Cancels the addition of a new part and redirects the user to the main screen.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void toMainForm(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 965, 500);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This is the EventHandler for the Save button.
     * Adds a new item to inventory, displays the item in the Parts TableView and redirects the user to the main screen.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     *
     * <p><b>
     * RUNTIME ERROR:
     * When saving a new created item, it worked perfectly when the user entered an inventory number that would be between max and min,
     * however, it would not save the item if the user entered an inventory number that was equal to max or min.
     * To correct the problem, within the if statement in addition to the two AND operators, I added two OR operators that would check if the
     * inventory number entered is equal to max or min. If either case was true, then the item would be added since it is still within the range.
     * </b></p>
     *
     */
    public void onActionSaveProduct(ActionEvent actionEvent) throws IOException {

        try {

            /** Gets user input from the TextFields and assigns the values to local variables.*/

            String name = productNameTxt.getText();
            int stock = Integer.parseInt(productInvTxt.getText());
            double price = Double.parseDouble(productPriceTxt.getText());
            int max = Integer.parseInt(productMaxTxt.getText());
            int min = Integer.parseInt(productMinTxt.getText());

            /**If statement that verifies if the stock level is between Max and Min.*/

            if (stock < max && stock > min || stock == max || stock == min) {

                /** Sets the fields with the values from the local variables.*/

                product.setId(Inventory.incrementProductId()); /** ID is set by calling a method that increments its value.*/
                product.setName(name);
                product.setStock(stock);
                product.setPrice(price);
                product.setMin(min);
                product.setMax(max);

                Inventory.addProduct(product); /** Product is than added to inventory by calling the addProduct method.*/

                /**Returns the user to the main form**/

                Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
                Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                Scene scene = new Scene(root, 965, 500);
                stage.setScene(scene);
                stage.show();

            } else if(max < stock){ /** Verifies that Stock is not greater than Max and executes error message.*/

                Alert stockAlert = new Alert(Alert.AlertType.ERROR);
                stockAlert.setTitle("Inventory Error");
                stockAlert.setContentText("Inventory should be between Max and Min.");
                stockAlert.showAndWait();
            }
            else if(max < min){ /** Verifies that Min is not greater than Nax and executes error message.*/

                Alert stockAlert = new Alert(Alert.AlertType.ERROR);
                stockAlert.setTitle("Inventory Error");
                stockAlert.setContentText("Min should be less than Max.");
                stockAlert.showAndWait();
            }
            else if(stock < min){ /** Verifies that Stock is not less than Min and executes error message.*/

                Alert stockAlert = new Alert(Alert.AlertType.ERROR);
                stockAlert.setTitle("Inventory Error");
                stockAlert.setContentText("Inventory should be between Max and Min.");
                stockAlert.showAndWait();
            }

        }
        catch (NumberFormatException e) /** Catches exemptions in case user enters wrong data type in the fields.*/
            {

                /** Displays error message in case the user inputs invalid values into the fields. */
                Alert emptyField = new Alert(Alert.AlertType.ERROR);
                emptyField.setTitle("Error Dialog");
                emptyField.setContentText("""
                                Please make sure you enter correct values in the fields.\s
                                - Inv should be a whole number.\s
                                - Price should contain decimals.\s
                                - Max should be a whole number.\s
                                - Min should be a whole number.\s
                                - Machine ID should be a whole number.\s
                                """);
                emptyField.showAndWait();
            }
    }

}

