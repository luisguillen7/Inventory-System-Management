
package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/** This class displays the Add Part screen where the user can add a new part to inventory.*/
public class AddPartController implements Initializable{

    /**UI Control RadioButton for In-House.*/
    @FXML
    public RadioButton inHouseRBtn;

    /**UI Control RadioButton for Outsourced.*/
    @FXML
    public RadioButton outsourcedRBtn;

    /**UI Control TextField for ID.*/
    @FXML
    public TextField partIDTxt;

    /**UI Control TextField for Name.*/
    @FXML
    public TextField partNameTxt;

    /**UI Control TextField for Inv.*/
    @FXML
    public TextField partInvTxt;

    /**UI Control TextField for Price/Cost.*/
    @FXML
    public TextField partPriceCostTxt;

    /**UI Control TextField for Max.*/
    @FXML
    public TextField partMaxTxt;

    /**UI Control TextField for Min.*/
    @FXML
    public TextField partMinTxt;

    /**UI Control TextField for Machine ID.*/
    @FXML
    public TextField partMachineIdCompanyNameTxt;

    /**UI Control Label for changing name.*/
    @FXML
    public Label changeLabel;

    /** Creates an In-House object and initializes its values to null.*/
    InHouse newInHouseObject = new InHouse(0, null, 0.0, 0, 0, 0,0);

    /** Creates an Outsource object and initializes its values to null.*/
    Outsourced newOutsourceObject = new Outsourced(0, null, 0.0, 0, 0, 0,null);

    /**This is the initialize method. This is the first method that is called when the screen associated with this controller gets instantiated.*/
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }

    /**
     *This is the EventHandler method for the Save button.
     * A new part can be created, added to inventory and returns to the main screen.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     *
     * <p><b>
     * RUNTIME ERROR:
     * When saving a new created item, it worked perfectly when the user entered an inventory number that would be between max and min,
     * however, it would not save the item if the user entered an inventory number that was equal to max or min.
     * To correct the problem, within the if statement in addition to the two AND operators, I added two OR operators that would check if the
     * inventory number entered is equal to max or min. If either case was true, then the item would be added since it is still within the range.
     * </b></p>
     *
     */
    public void onActionSavePart(ActionEvent actionEvent) throws IOException {
        try
        {
            String name = partNameTxt.getText(); /**Getting input from the partNameTxt field and assigning it to string variable name**/
            int inv = Integer.parseInt(partInvTxt.getText()); /**Getting input from the partInvTxt and converting it to an integer**/
            double price = Double.parseDouble(partPriceCostTxt.getText()); /**Getting input from the partPriceCostTxt and converting it to a double**/
            int max = Integer.parseInt(partMaxTxt.getText()); /**Getting input from the partMaxTxt and converting it to an integer**/
            int min = Integer.parseInt(partMinTxt.getText()); /**Getting input from the partMinTxt and converting it to an integer**/

            /**Checks if the In-House RadioButton is checked and if the stock level is between the min and max levels*/
            if(inHouseRBtn.isSelected() && inv < max && inv > min || inv == max || inv == min)
                {
                    /**Getting input from the partMachineCompanyNameTxt and converting it to an integer**/
                    int machineID = Integer.parseInt(partMachineIdCompanyNameTxt.getText());

                    /** Calling the setters to set the values of the newInHouseObject.*/

                    newInHouseObject.setId(Inventory.incrementPartId());
                    newInHouseObject.setName(name);
                    newInHouseObject.setStock(inv);
                    newInHouseObject.setPrice(price);
                    newInHouseObject.setMax(max);
                    newInHouseObject.setMin(min);
                    newInHouseObject.setMachineId(machineID);

                    /** Add the In-House object to the Parts list. */

                    Inventory.addPart(newInHouseObject);

                    /**Returns the user to the main form**/
                    Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root, 965, 500);
                    stage.setScene(scene);
                    stage.show();
                }

                /** Checks if Outsource RadioButton is selected and if stock level is between Max and Min levels.  */
                else if(outsourcedRBtn.isSelected() && inv < max && inv > min)
                {
                    /**Getting input from the Company Name TextField*/
                    String companyName = partMachineIdCompanyNameTxt.getText();

                    /** Calling the setters to set the values of the newOutsourceObject.*/

                    newOutsourceObject.setId(Inventory.incrementPartId());
                    newOutsourceObject.setName(name);
                    newOutsourceObject.setStock(inv);
                    newOutsourceObject.setPrice(price);
                    newOutsourceObject.setMax(max);
                    newOutsourceObject.setMin(min);
                    newOutsourceObject.setCompanyName(companyName);

                    /** Add the In-House object to the Parts list. */

                    Inventory.addPart(newOutsourceObject);

                    /**Returns the user to the main form*/
                    Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root, 965, 500);
                    stage.setScene(scene);
                    stage.show();
                }

                /**Checks if Max level is less than stock level or if Min level is greater than Max*/
                else if(max < inv)
                {
                    Alert invError = new Alert(Alert.AlertType.ERROR);
                    invError.setTitle("Error Dialog");
                    invError.setContentText("Inventory should be between Max and Min.");
                    invError.showAndWait();
                }

                 /** Checks if Min level is greater than the Max level. */
                else if (min > max)
                {
                    Alert invError = new Alert(Alert.AlertType.ERROR);
                    invError.setTitle("Error Dialog");
                    invError.setContentText("Min should be less than Max.");
                    invError.showAndWait();
                }
                /** Checks if stock level is less than Min level. */
                else if (min > inv)
                {
                    Alert invError = new Alert(Alert.AlertType.ERROR);
                    invError.setTitle("Error Dialog");
                    invError.setContentText("Inventory should be between Max and Min.");
                    invError.showAndWait();
                }
        }
        catch (NumberFormatException e ) /** Catches exemptions in case user enters wrong data type in the fields.*/
        {
            /** Displays error message in case the user inputs invalid values into the fields. */
            Alert emptyField = new Alert(Alert.AlertType.ERROR);
            emptyField.setTitle("Error Dialog");
            emptyField.setContentText("""
                            Please make sure you enter correct values in the fields.\s
                            - Inv should be a whole number.\s
                            - Price should contain decimals.\s
                            - Max should be a whole number.\s
                            - Min should be a whole number.\s
                            - Machine ID should be a whole number.\s
                            """);
            emptyField.showAndWait();
        }

    }

    /**
     * This is the EventHandler for the Cancel button.
     * When the Cancel button is clicked the user is sent back to the main screen.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void toMainForm(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        Stage stage = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 965, 500);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This is the EventHandler for the In-House radio button.
     * Sets the label to Machine ID when the user selects the In-House radio button.
     * @param actionEvent Not used.
     */
    public void onInHouse(ActionEvent actionEvent) {
        changeLabel.setText("Machine ID");

    }

    /**
     * This is the EventHandler for Outsource radio-button.
     * Sets the label to Company Name when the user selects Outsource radio button.
     * @param actionEvent Not used.
     */
    public void onOutsourced(ActionEvent actionEvent) {
        changeLabel.setText("Company Name");
    }

}
