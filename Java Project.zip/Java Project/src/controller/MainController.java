package controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class displays the Main screen. The user may add, modify and delete parts or products from this screen. */
public class MainController implements Initializable {

    /** UI Control Label for Part.*/
    @FXML
    public Label partLbl;

    /** UI Control TextField for Search.*/
    @FXML
    public TextField partSearchTxt;

    /** UI Control TableView for Part objects.*/
    @FXML
    public TableView<Part> partTableView;

    /** UI Control TextField for Search bar.*/
    @FXML
    public TextField productSearchTxt;

    /** TableColumn for Part ID.*/
    @FXML
    private TableColumn<Part, Integer> partIDCol;

    /** TableColumn for Part Name.*/
    @FXML
    private TableColumn<Part, String> partNameCol;

    /** TableColumn for Part Inventory.*/
    @FXML
    private TableColumn<Part, Integer> partInventoryLevelCol;

    /** TableColumn for Part Price.*/
    @FXML
    private TableColumn<Part, Double> partPriceCostCol;

    /** UI Control Button for Adding a part.*/
    @FXML
    public Button partAddBtn;

    /** UI Control Button for Modifying a part.*/
    @FXML
    public Button partModifyBtn;

    /** UI Control Button for Deleting a part.*/
    @FXML
    public Button partDeleteBtn;

    /** UI Control TableView for Product objects.*/
    @FXML
    public TableView<Product> productTableView;

    /** TableColumn for Product ID.*/
    @FXML
    public TableColumn<Product, Integer> productIDCol;

    /** TableColumn for Product Name.*/
    @FXML
    public TableColumn<Product, String> productNameCol;

    /** TableColumn for Product Inventory.*/
    @FXML
    public TableColumn<Product, Integer> productInventoryLevelCol;

    /** TableColumn for Product Price.*/
    @FXML
    public TableColumn<Product, Double> productPriceCostCol;

    /** This is the initialize method. This is the first method that is called when the screen associated with this controller gets instantiated.*/
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /**PART TABLEVIEW*/

        /**This statement sets items inside the Part Table*/
        partTableView.setItems(Inventory.getAllParts());

        /**This statement gets the id from the getId method of every Part object created.*/
        partIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        /**This statement gets the name from the getName method of every Part object created.*/
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        /**This statement gets the inventory from the getStock method of every Part object created.*/
        partInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        /**This statement gets the price from the getPrice method of every Part object created.*/
        partPriceCostCol.setCellValueFactory(new PropertyValueFactory<>("price"));


        /**PRODUCT TABLEVIEW*/

        /**This statement sets items inside the Product Table*/
        productTableView.setItems(Inventory.getAllProducts());

        /**This statement gets the id from the getId method of every Product object created.*/
        productIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        /**This statement gets the name from the getName method of every Product object created.*/
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        /**This statement gets the inventory from the getStock method of every Product object created.*/
        productInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        /**This statement gets the price from the getPrice method of every Product object created.*/
        productPriceCostCol.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    /**
     * This is the EventHandler for the Add button on the Parts table.
     * Sends user to Add Part screen where the user can add a new part to inventory.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void toAddPartForm(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/view/AddPartForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 600, 600);
        stage.setTitle("Add Part Form");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This is the EventHandler for the Modify button on the Parts table.
     * Sends user to the Modify screen where the user can modify data and update the item selected.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void toModifyPartForm(ActionEvent actionEvent) throws IOException {

        /**Creates a new loader object.*/
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/ModifyPartForm.fxml"));
        loader.load();

        /**Creates a reference variable called MPController for the ModifyPartController class.
         *And loader.getController method gets the Controller associated with the ModifyPartForm.fxml document.
         *MPController can now be used to access public methods inside the ModifyPartController.*/
        ModifyPartController MPController = loader.getController();

        /**Creates a reference variable for the Part class and sets it equal to the selected item in the partTableView.*/
        Part selectedPart = partTableView.getSelectionModel().getSelectedItem();

        /**Creates a variable and sets it equal to the selected index in the partTableView.*/
        int selectedIndex = partTableView.getSelectionModel().getSelectedIndex();

        /**If the user selected a part in the partTableView.*/
        if (selectedPart != null) {
            /**MPController is used to access the sendPartData method*/
            MPController.sendPartData(selectedIndex, selectedPart);

            /**Loads Modify Part Screen */
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene, 600, 600));
            stage.show();
        } else {
            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error Dialog");
            selectItemError.setContentText("Please select an item to modify.");
            selectItemError.showAndWait();
        }
    }

    /**
     * This is the EventHandler for the Add button on the Products table.
     * Sends the user to the Add Product screen where the user can create a new product and add it to inventory.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void toAddProductForm(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/view/AddProductForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene3 = new Scene(root, 960, 660);
        stage.setTitle("Add Product Form");
        stage.setScene(scene3);
        stage.show();
    }

    /**
     * This is the EventHandler for the Modify button on the Product table.
     * Sends the user to Modify Product screen where the user can modify the selected item.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void toModifyProductForm(ActionEvent actionEvent) throws IOException {

        /**Creates a new loader object.*/

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/ModifyProductForm.fxml"));
        loader.load();

        /** Creates a reference variable called MPController for the ModifyProductController class.
         * And loader.getController method gets the Controller associated with the ModifyPartForm.fxml document.
         * MPController can now be used to access public methods inside the ModifyPartController.*/
        ModifyProductController MPRController = loader.getController();

        /** Creates a reference variable for the Part class and sets it equal the selected item in the partTableView.*/

        Product selectedProduct = productTableView.getSelectionModel().getSelectedItem();

        /** Creates a variable and sets it equal to the selected index in the partTableView.*/

        int selectedIndex = productTableView.getSelectionModel().getSelectedIndex();

        /** If the user selected a part in the partTableView.*/

        if (selectedProduct != null) {

            /** MPController is used to access the sendPartData method.*/

            MPRController.sendProductData(selectedIndex, selectedProduct);

            /** Loads Modify Part Screen */

            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene, 960, 660));
            stage.show();

        }
        else {

            /** Displays error message when user does not select an item and hits the modify button.*/

            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error Dialog");
            selectItemError.setContentText("Please select an item to modify.");
            selectItemError.showAndWait();
        }
    }

    /**
     * This is the EventHandler for the Delete button on the Product table.
     * Deletes the item selected on the Products TableView.
     * @param actionEvent Not used.
     *
     * <p><b>
     * RUNTIME ERROR:
     * After selecting an item to delete, the confirmation dialogue box would display in order to confirm the deletion of the item.
     * The item should be deleted if the user clicked OK and the process should be terminated if the user clicked CANCEL, but regardless
     * of the button clicked, the item would be deleted.
     * In order to fix this, I created an Optional ButtonType instance that would store an alert instance that calls the dialogue box.
     * Then setting a condition where if the ButtonType has a value, retrieve that value and if that is equal to the ButtonType.Ok, then
     * it executes code that deletes the item selected and displays a message confirming the deletion.
     * Otherwise if the value is not equal to ButtonType.OK (CANCEL) then the
     * process is terminated.
     * </b></p>
     *
     */
    public void onActionDeleteProduct(ActionEvent actionEvent) {

        /** Creates a product object that stores an item selected from the Products TableView.*/
        Product selectedProduct = productTableView.getSelectionModel().getSelectedItem();

        /** Checks if an item is selected on the Product TableView.*/

        if(selectedProduct != null)
        {

            /** Checks if the selected product to delete has associated parts.*/

            if(selectedProduct.getAllAssociatedParts().isEmpty())
            {
                /** Confirm if the item should be removed.*/

                Alert confirmDeletion = new Alert(Alert.AlertType.CONFIRMATION);
                confirmDeletion.setTitle("Item Deletion");
                confirmDeletion.setContentText("Are you sure you want to delete this item?");
                Optional<ButtonType> result = confirmDeletion.showAndWait();

                if(result.isPresent() && result.get() == ButtonType.OK)
                {
                    /** Calls method that deletes selected item.*/

                    Inventory.deleteProduct(selectedProduct);

                    /** Displays dialog message when part is removed.*/

                    Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                    confirmedDeletion.setTitle("Product");
                    confirmedDeletion.setContentText("Product deleted successfully.");
                    confirmedDeletion.show();
                }
                else{

                    /** Display error message if user clicks cancel in the confirmation dialogue box.*/

                    Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                    confirmedDeletion.setTitle("Parts");
                    confirmedDeletion.setContentText("Product was not deleted.");
                    confirmedDeletion.show();

                }
            }
            else
            {

                Alert deleteError = new Alert(Alert.AlertType.INFORMATION);
                deleteError.setTitle("Product");
                deleteError.setContentText("Product can not be deleted because it has associated parts." + "\n" +
                                                 "Remove its associated parts in order to delete product.");
                deleteError.show();

            }
        }
        else
        {
            /** Display error message if user does not select anything.*/

            Alert deleteError = new Alert(Alert.AlertType.ERROR);
            deleteError.setTitle("Error Dialog");
            deleteError.setContentText("Please select an item to delete.");
            deleteError.showAndWait();
        }
    }


    /**
     * This is the EventHandler for the Delete button on the Parts table.
     * Deletes an item selected from the Parts TableView.
     * @param actionEvent Not used.
     *
     * <p><b>
     * RUNTIME ERROR:
     * After selecting an item to delete, the confirmation dialogue box would display in order to confirm the deletion of the item.
     * The item should be deleted if the user clicked OK and the process should be terminated if the user clicked CANCEL, but regardless
     * of the button clicked, the item would be deleted.
     * In order to fix this, I created an Optional ButtonType instance that would store an alert instance that calls the dialogue box.
     * Then setting a condition where if the ButtonType has a value, retrieve that value and if that is equal to the ButtonType.Ok, then
     * it executes code that deletes the item selected and displays a message confirming the deletion.
     * Otherwise if the value is not equal to ButtonType.OK (CANCEL) then the
     * process is terminated.
     * </b></p>
     *
     */
    public void onActionDelete(ActionEvent actionEvent) {

        /**Calls deletePart method which accepts a Part object. */
        if (partTableView.getSelectionModel().getSelectedItem() != null) {

            /** Double-check if the item should be removed.*/

            Alert onExit = new Alert(Alert.AlertType.CONFIRMATION);
            onExit.setTitle("Item Deletion");
            onExit.setContentText("Are you sure you want to delete this item?");
            Optional<ButtonType> result = onExit.showAndWait();

            if(result.isPresent() && result.get() == ButtonType.OK) {

                /** Calls method that deletes selected item.*/

                Inventory.deletePart(partTableView.getSelectionModel().getSelectedItem());

                /** Displays dialog message when part is removed.*/

                Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                confirmedDeletion.setTitle("Parts");
                confirmedDeletion.setContentText("Part deleted successfully.");
                confirmedDeletion.show();
            }
            else{

                /** Display error message if user clicks cancel in the confirmation dialogue box.*/

                Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                confirmedDeletion.setTitle("Parts");
                confirmedDeletion.setContentText("Part was not deleted.");
                confirmedDeletion.show();

            }
        } else {

            /** Display error message if user does not select anything.*/

            Alert deleteError = new Alert(Alert.AlertType.ERROR);
            deleteError.setTitle("Error Dialog");
            deleteError.setContentText("Please select an item to delete");
            deleteError.showAndWait();
        }
    }

    /**
     * This is the EventHandler for the Exit button on the Main screen.
     * It terminates the application.
     * @param actionEvent Not used.
     *
     * <p><b>
     * RUNTIME ERROR:
     * The exit button would terminate the application when the OK button on the confirmation dialogue box was clicked
     * and also terminate the application if the CANCEL button was clicked.
     * To fix the problem I created an OPTIONAL ButtonType instance variable called result and assigned it to store the onExit variable that displays the
     * confirmation dialogue box.
     * Then inside an IF statement, using the result variable, I called the isPresent() to verify it holds a value
     * and the get() to retrieve that result and lastly verify if that retrieved result is equal to the Button.OK of the confirmation dialogue box.
     * If result.get() does equal to the Button.OK then it terminates the application, if it doesn't then the user remains
     * in the application allowing the CANCEL button to do its function.
     * </b></p>
     */
    public void toExit(ActionEvent actionEvent) {

            Alert onExit = new Alert(Alert.AlertType.CONFIRMATION);
            onExit.setTitle("Exit Main");
            onExit.setContentText("Are you sure you want to exit the application?");
            Optional<ButtonType> result = onExit.showAndWait();
            if(result.isPresent() && result.get() == ButtonType.OK)
            System.exit(0);

    }

    /**
     * This is the EventHandler for the Search Part TextField.
     * It filters and sets items on the TableView when the item is searched by name and highlights the item when the item is searched by ID.
     * @param actionEvent Not used.
     */
    public void onSearchAction(ActionEvent actionEvent) {

        try {
            String partSearched = partSearchTxt.getText(); /** Gets user input from the Search TextField.*/
            int id = Integer.parseInt(partSearched); /** Converts the item searched from a string to an integer.*/
            Part t = Inventory.lookupPart(id);  /** Calls the lookupPart method and assigns its value to a part object.*/
            partTableView.getSelectionModel().select(t); /** Highlights the item looked up for in the Parts TableView.*/

        } catch (Exception e) { /** Executes if the item is searched by name*/

            /**Searches and filters a searched Part by entering the name of the part*/
            String partSearched = partSearchTxt.getText();
            ObservableList<Part> parts = Inventory.lookupPart(partSearched);
            partTableView.setItems(parts);
        }

        if(!(Inventory.partFound)){ /** Executes if the item is not found.*/

             Alert alert = new Alert(Alert.AlertType.WARNING);
             alert.setTitle("Warning Dialog");
             alert.setContentText("Part Not Found");
             alert.showAndWait();
             partSearchTxt.setText("");
        }
    }

    /**
     * This is the EventHandler for the Product's Search TextField.
     * It filters and sets items on the TableView when the item is searched by name and highlights the item when the item is searched by ID.
     * @param actionEvent Not used.
     */

    public void onSearchProductAction(ActionEvent actionEvent) {
        try {
            String productSearched = productSearchTxt.getText(); /** Gets user input from the Search TextField.*/
            int id = Integer.parseInt(productSearched); /** Converts the item searched from a string to na integer.*/
            Product t = Inventory.lookUpProduct(id); /** Calls the lookUpProduct method and assigns its value to a product object.*/
            productTableView.getSelectionModel().select(t); /** Highlights the item searched on the Products TableView.*/

        } catch (Exception e){ /** Executes exemption if the item is searched by name.*/

            String partSearched = productSearchTxt.getText(); /** Gets user input from the Search TextField.*/
            ObservableList<Product> products = Inventory.lookUpProduct(partSearched); /** Calls lookUpProduct method and assigns value to a list variable.*/
            productTableView.setItems(products); /** Sets the items on the Product TableView.*/
        }

        if(!(Inventory.partFound)){ /** Executes an error message if the item is not found.*/

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning Dialog");
            alert.setContentText("Part Not Found");
            alert.showAndWait();
            productSearchTxt.setText("");
        }
    }
}


