package model;

/** This is a subclass of Part. It allows the creation of an In-House object.*/
public class InHouse extends Part{

    private int machineId; /** Defines a field to store the Machine ID of an In-House Object.*/

    /**
     * This is the constructor for an In-House object.
     * It sets the values of the various fields wherever this constructor is called throughout the program.
     * @param id The ID of In-House part.
     * @param name The name of the In-House part.
     * @param price The price of the In-House part.
     * @param stock The stock of the In-House part.
     * @param min The min quantity of the In-House part.
     * @param max The max quantity of the In-House part.
     * @param machineId The machine ID of the In-House part.
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;
    }

    /**
     * This is the getter for the Machine ID.
     * It retrieves the Machine ID of an In-House part.
     * @return Returns machine ID value.
     */
    public int getMachineId() {
        return machineId;
    }

    /**
     * This is the setter for the Machine ID.
     * It sets the value for the field.
     * @param machineId Stores the machine ID given.
     */
    public void setMachineId(int machineId) {
        this.machineId = machineId;
    }
}


