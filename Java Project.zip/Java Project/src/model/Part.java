package model;

/** This is an abstract class. It defines the variables, setters and getters and a constructor to create Part objects. */
public abstract class Part {

    /** Defines variables and their data types for the Part object attributes.*/
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    /**
     * This is a constructor for a Part object.
     * @param id The ID of a part.
     * @param name The name of a part.
     * @param price The price of a part.
     * @param stock The stock of a part.
     * @param min The min quantity of part.
     * @param max The max quantity of part.
     */
    public Part(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /** This method gets the ID for the part.
     *  The ID is a number that uniquely identifies a part.
     * @return Returns the ID.
     */
    public int getId() {
        return id;
    }

    /** This method sets the ID for the part.
     * The ID is a number that uniquely identifies a part.
     * @param id Accepts and sets an ID.
     */
    public void setId(int id) {
        this.id = id;
    }

    /** This method gets the name for the part.
     *  Retrieves the name that was given to the part.
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }

    /** This method sets the name for the part.
     * Sets the name for the part.
     * @param name Accepts and sets name for the part.
     */
    public void setName(String name) {
        this.name = name;
    }

    /** This method gets the price for the part.
     *  Gets the price that was given to the part.
     * @return Returns the price.
     */
    public double getPrice() {
        return price;
    }

    /**This method sets the price for the part.
     * Sets the price for the part.
     * @param price Accepts and sets price for the part.
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /** This method gets the stock for the part.
     *  Gets the stock that was given for the part.
     * @return Returns the stock.
     */
    public int getStock() {
        return stock;
    }

    /**This method sets the stock for the part.
     * Sets the stock for the part.
     * @param stock Accepts and sets stock for the part.
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /** This method gets the minimum level of stock for the part.
     *  Gets the minimum level of stock that was given for the part.
     * @return Returns the minimum level stock.
     */
    public int getMin() {
        return min;
    }

    /**This method sets the minimum level of stock for the part.
     * Sets the minimum level os stock for the part.
     * @param min Accepts and sets minimum level for the part.
     */
    public void setMin(int min) {
        this.min = min;
    }

    /** This method gets the maximum level of stock for the part.
     *  Gets the maximum level of stock that was given for the part.
     * @return Returns the maximum level stock.
     */
    public int getMax() {
        return max;
    }

    /**This method sets the maximum level of stock for the part.
     * Sets the maximum level os stock for the part.
     * @param max Accepts and sets maximum level for the part.
     */
    public void setMax(int max) {
        this.max = max;
    }

}
