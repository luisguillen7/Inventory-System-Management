package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/** This is the Product class and is dependent on the Part class. It defines the variables, setters and getters and a constructor to create Product objects. */
public class  Product {

    private ObservableList<Part> associatedParts = FXCollections.observableArrayList(); /** Creates an ObservableList for Part objects.*/

    /** Defines variables and their data types for the Product object attributes.*/

    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    /**
     * This is a constructor for a Product object.
     * @param id The ID of a product.
     * @param name The name of a product.
     * @param price The price of a product.
     * @param stock The stock of a product.
     * @param min The min quantity of product.
     * @param max The max quantity of product.
     */
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /** This method gets the ID for the product.
     *  The ID is a number that uniquely identifies a product.
     * @return Returns the ID.
     */
    public int getId() {
        return id;
    }

    /** This method sets the ID for the product.
     * The ID is a number that uniquely identifies a product.
     * @param id Accepts and sets an ID.
     */
    public void setId(int id) {

        this.id = id;
    }

    /** This method gets the name for the product.
     *  Retrieves the name that was given to the product.
     * @return Returns the name.
     */
    public String getName() {

        return name;
    }

    /** This method sets the name for the product.
     * Sets the name for the product.
     * @param name Accepts and sets name for the product.
     */
    public void setName(String name) {
        this.name = name;
    }

    /** This method gets the price for the product.
     *  Gets the price that was given to the product.
     * @return Returns the price.
     */
    public double getPrice() {
        return price;
    }

    /**This method sets the price for the product.
     * Sets the price for the product.
     * @param price Accepts and sets price for the product.
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /** This method gets the stock for the product.
     *  Gets the stock that was given for the product.
     * @return Returns the stock.
     */
    public int getStock() {
        return stock;
    }

    /**This method sets the stock for the product.
     * Sets the stock for the product.
     * @param stock Accepts and sets stock for the product.
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /** This method gets the minimum level of stock for the product.
     *  Gets the minimum level of stock that was given for the product.
     * @return Returns the minimum level stock.
     */
    public int getMin() {
        return min;
    }

    /**This method sets the minimum level of stock for the product.
     * Sets the minimum level os stock for the product.
     * @param min Accepts and sets minimum level for the product.
     */
    public void setMin(int min) {

        this.min = min;
    }

    /** This method gets the maximum level of stock for the product.
     *  Gets the maximum level of stock that was given for the product.
     * @return Returns the maximum level stock.
     */
    public int getMax() {

        return max;
    }

    /**This method sets the maximum level of stock for the product.
     * Sets the maximum level os stock for the product.
     * @param max Accepts and sets maximum level for the product.
     */
    public void setMax(int max) {
        this.max = max;
    }

    /**
     * This method adds a new associated part.
     * It adds a new part object to the associated part ObservableList.
     * @param part A part object.
     */
    public void addAssociatedPart(Part part){
        associatedParts.add(part);
    }

    /**
     * This method deletes an associated part.
     * An item can be deleted from the ObservableList.
     * @param selectAssociatedPart The selected associated part to be deleted.
     * @return Returns the ObservableList without the deleted part.
     */
    public boolean deleteAssociatedPart(Part selectAssociatedPart){
        return associatedParts.remove(selectAssociatedPart);
    }

    /**
     * This method gets the Associated Parts ObservableList.
     * It gets all the items that make up the ObservableList.
     * @return Returns the Part ObservableList.
     */
    public ObservableList<Part> getAllAssociatedParts(){
        return associatedParts;
    }

}
