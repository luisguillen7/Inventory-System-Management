package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/** This is the Inventory class and is dependent on the Part and Product classes. It contains the ObservableLists and several methods that allow the addition, deletion, look up and manipulation of objects.*/
public class Inventory {

    private static int nextPartId = 1; /** Defines variable nextPartId and initializes it to 1.*/

    private static int nextProductId = 1; /** Defines variable nextProductId and initializes it to 1.*/

    public static boolean partFound; /** Defines variable partFound.*/

    /**
     * This is the method for incrementing a part ID.
     * It increments the part ID by 1.
     * @return Returns the part ID + 1.
     */
    public static int incrementPartId(){
        return nextPartId++;
    }

    /**
     * This is the method for incrementing a product ID.
     * It increments the product ID by 1.
     * @return Returns the product ID + 1.
     */
    public static int incrementProductId(){
        return nextProductId++;
    }

    private static ObservableList<Part> allParts = FXCollections.observableArrayList(); /** Creates ObservableList for Part objects.*/

    private static ObservableList<Product> allProducts = FXCollections.observableArrayList(); /** Creates ObservableList for Product objects.*/

    /**
     * This method adds a new part.
     * It adds a new part to the Part ObservableList.
     * @param newPart A part object.
     */
    public static void addPart(Part newPart){
        allParts.add(newPart);
    }

    /**
     * This method adds a new product.
     * It adds a new part to the Product ObservableList.
     * @param newProduct A product object.
     */
    public static void addProduct(Product newProduct){
        allProducts.add(newProduct);
    }

    /**
     * This method searches a part by their ID.
     * @param partId The part ID searched for.
     * @return Returns matching part ID.
     */
    public static Part lookupPart(int partId){

        partFound = false;

        ObservableList<Part> allParts = Inventory.getAllParts();

        for(int i = 0; i < allParts.size(); i++){
            Part t = allParts.get(i);
            if(t.getId() == partId){
                partFound = true;
                return t;
            }
        }       return null;
    }

    /**
     * This method searches a product by their ID.
     * @param productId The product ID searched for.
     * @return Returns matching product ID.
     */
    public static Product lookUpProduct(int productId){

        partFound = false;

        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for(int i =  0; i <allProducts.size(); i++){
                Product t = allProducts.get(i);
                if(t.getId() == productId){
                    partFound = true;
                    return t;
                }
        } return null;
    }


    /**
     * This method searches a part by their name.
     * @param partialName The part name searched for.
     * @return Returns matching part name.
     */
    public static ObservableList<Part> lookupPart(String partialName){

        partFound = false;

        ObservableList<Part> namedParts = FXCollections.observableArrayList();

        for(Part p: allParts){
            if(p.getName().contains(partialName)) {
                namedParts.add(p);
            }
        }
        if(namedParts.isEmpty())
            return allParts;

        partFound = true;
        return namedParts;
    }

    /**
     * This method searches a product by their name.
     * @param partialName The product name searched for.
     * @return Returns matching product name.
     */
    public static ObservableList<Product> lookUpProduct(String partialName){

        partFound = false;

        ObservableList<Product> namedProducts = FXCollections.observableArrayList();

        for(Product p: allProducts){
            if(p.getName().contains(partialName)){
                namedProducts.add(p);
            }
        }
        if(namedProducts.isEmpty()){
            return allProducts;
        }
        partFound = true;
        return namedProducts;
    }

    /**
     * This method updates a part selected.
     * It can be used to update fields from a part.
     * @param index The index of the item in the ObservableList to be updated.
     * @param selectedPart The selected part object.
     */
    public static void updatePart(int index, Part selectedPart){
        allParts.set(index, selectedPart);
    }

    /**
     * This method updates a product selected.
     * It can be used to update fields from a product.
     * @param index The index of the item in the ObservableList to be updated.
     * @param selectedProduct The selected product object.
     */
    public static void updateProduct(int index, Product selectedProduct){
        allProducts.set(index, selectedProduct);
    }

    /**
     * This method deletes a part.
     * An item can be deleted from the ObservableList.
     * @param selectedPart The selected part to be deleted.
     * @return Returns the ObservableList without the deleted part.
     */
    public static boolean deletePart(Part selectedPart){
        return allParts.remove(selectedPart);
    }

    /**
     * This method deletes a product.
     * An item can be deleted from the ObservableList.
     * @param selectedProduct The selected product to be deleted.
     * @return Returns the ObservableList without the deleted product.
     */
    public static boolean deleteProduct(Product selectedProduct){
        return allProducts.remove(selectedProduct);
    }

    /**
     * This method gets the Part ObservableList.
     * It gets all the items that make up the ObservableList.
     * @return Returns the Part ObservableList.
     */
    public static ObservableList<Part> getAllParts(){
        return allParts;
    }

    /**
     * This method gets the Product ObservableList.
     * It gets all the items that make up the ObservableList.
     * @return Returns the Product ObservableList.
     */
    public static ObservableList<Product> getAllProducts(){
        return allProducts;
    }

}
