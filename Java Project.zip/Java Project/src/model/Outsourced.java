package model;

/** This is a subclass of Part. It allows the creation of an OutSource object.*/
public class Outsourced extends Part {

    private String companyName; /** Defines a field to store the Company Name for an OutSource Object.*/

    /**
     * This is the constructor for an Outsource object.
     * It sets the values of the various fields wherever this constructor is called throughout the program.
     * @param id The ID of Outsource part.
     * @param name The name of Outsource part.
     * @param price The price of Outsource part.
     * @param stock The stock of Outsource part.
     * @param min The min quantity of Outsource part.
     * @param max The max quantity of Outsource part.
     * @param companyName The company name of Outsource part.
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }

    /**
     * This is the getter for the Company Name.
     * It retrieves the Company Name of Outsourced part.
     * @return Returns Company Name value.
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * This is the setter for the Company Name.
     * It sets the value for the field.
     * @param companyName Stores the company name given.
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
