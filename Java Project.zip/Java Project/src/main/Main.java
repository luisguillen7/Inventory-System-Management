package main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;

/** This class launches an Inventory Management System application. */
public class Main extends Application {

    /**
     * This method creates hardcoded data to populate the Parts TableView.
     * In-House and Outsource objects are created and are added to inventory.
     */
    public static void addPartTestData(){
        InHouse object1 = new InHouse(Inventory.incrementPartId(), "Brakes", 15.99, 10, 1, 20, 15);
        InHouse object2 = new InHouse(Inventory.incrementPartId(), "Wheel", 11.99, 10, 1, 20, 12);
        Outsourced  object3 = new Outsourced(Inventory.incrementPartId(), "Rim", 15.99, 10, 1, 20, "Acme");

        /**Calls the inventory addPart method to add a newly created In-House object.*/
        Inventory.addPart(object1);
        Inventory.addPart(object2);
        Inventory.addPart(object3);
    }

    /**
     * This method creates hardcoded data to populate the Products TableView.
     * Product objets are created and are added to inventory.
     */
    public static void addProductTestData(){
        Product object1 = new Product(Inventory.incrementProductId(), "Giant Bicycle", 15.99, 10, 1, 20);
        Product object2 = new Product(Inventory.incrementProductId(), "Scott Bicycle", 11.99, 10, 1, 20);
        Product object3 = new Product(Inventory.incrementProductId(), "GT Bike", 15.99, 10, 1, 20);

        Inventory.addProduct(object1);
        Inventory.addProduct(object2);
        Inventory.addProduct(object3);
    }

    /**
     * This is the main method.
     * It launches the application and calls methods to display data on both TableViews.
     * The javadoc folder is located: Java Project\ javadoc  (Inside the Java Project Folder).
     * @param args
     *
     * <p><b>
     * FUTURE ENHANCEMENTS:
     * Perhaps the organization would like to quickly view and keep track of the companies where they are getting their outsource parts from.
     * By providing an extra button called "View Outsourcing Companies" in the main controller that sends the user to
     * another window that displays a TableView and populate it automatically with the name of the company name and the part supplied
     * everytime an outsource item is added to inventory.
     * </b></p>
     *
     */
    public static void main(String[] args){
        addPartTestData();
        addProductTestData();
        launch(args);
    }

     /**
      * This is the start method.
     * This displays the Main Form screen.
     * @param stage Displays the stage
     * @throws IOException To handle code failures if needed.
     */
    public void start(Stage stage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        stage.setTitle("Main Form");
        stage.setScene(new Scene(root, 965, 500));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }
}
